<?php

$con=mysqli_connect("localhost","onlin778_rohit","rohit1995","onlin778_sks");

?>
