<?php(employee_id,vender_id,product_title,product_list,
	product_brand,quntiti,price_our,sales_price,bike_round,product_profitt,
	product_los,product_date,product_status,product_specification,image)
?>