

<?php
$con = mysqli_connect("localhost","onlin778_rohit","rohit1995","onlin778_akasha123");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
